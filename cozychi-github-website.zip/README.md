# CozyChi Gift Store

A pink-and-blue CozyChi Gift Store portfolio website.

## Store
https://cozychi-gift-store-2.myshopify.com/

## Files
- `index.html` — website structure
- `style.css` — CozyChi design
- `script.js` — product categories and filtering

## Product collections
Home & Cozy Living, Drinkware & Desk, Stationery, Lifestyle Accessories, Self-Care & Wellness, and Gift Essentials.
