const shopUrl = "https://cozychi-gift-store-2.myshopify.com/";

const products = [
  ["Scented Candles","Home & Cozy","🕯️"],["Candle Accessories","Home & Cozy","🕯️"],["Wax Melt Warmers","Home & Cozy","🔥"],
  ["Mini Artificial Plants","Home & Cozy","🌿"],["Throw Blankets","Home & Cozy","🛋️"],["Wall Art Prints","Home & Cozy","🖼️"],
  ["Decorative Pillow Covers","Home & Cozy","🛏️"],["Ceramic Mugs","Drinkware & Desk","☕"],["Water Bottles","Drinkware & Desk","💧"],
  ["Desk Organizers","Drinkware & Desk","🗂️"],["Gel Pen Sets","Stationery","✍️"],["Journals","Stationery","📓"],
  ["Bookmarks","Stationery","🔖"],["Tote Bags","Lifestyle Accessories","👜"],["Phone Cases","Lifestyle Accessories","📱"],
  ["Laptop Sleeves","Lifestyle Accessories","💻"],["Cozy Socks","Lifestyle Accessories","🧦"],["Keychains","Lifestyle Accessories","🔑"],
  ["Self-Care Gift Boxes","Self-Care & Wellness","🎁"],["Self-Care Kits","Self-Care & Wellness","🧖🏽‍♀️"],
  ["Aromatherapy Diffusers","Self-Care & Wellness","🌸"],["Greeting Cards","Gift Essentials","💌"],
  ["Gift Bags","Gift Essentials","🎀"],["Stickers","Gift Essentials","✨"]
];

const filters = ["All", ...new Set(products.map(p => p[1]))];
const filterBox = document.getElementById("filters");
const grid = document.getElementById("productGrid");

function renderFilters(active="All"){
  filterBox.innerHTML = filters.map(f => `<button class="filter ${f===active?"active":""}" data-filter="${f}">${f}</button>`).join("");
  document.querySelectorAll(".filter").forEach(btn => btn.addEventListener("click", () => renderProducts(btn.dataset.filter)));
}

function renderProducts(category="All"){
  renderFilters(category);
  const list = category==="All" ? products : products.filter(p => p[1]===category);
  grid.innerHTML = list.map(([name,cat,icon]) => `
    <article class="product">
      <div class="product-icon">${icon}</div>
      <div class="category">${cat}</div>
      <h3>${name}</h3>
      <p>Explore this CozyChi collection and discover a thoughtful gift for your space or someone special.</p>
      <a href="${shopUrl}" target="_blank" rel="noopener">Shop on Shopify →</a>
    </article>
  `).join("");
}

renderProducts();

document.querySelector(".menu-toggle").addEventListener("click", () => {
  const nav = document.getElementById("navMenu");
  nav.style.display = nav.style.display === "flex" ? "none" : "flex";
  nav.style.flexDirection = "column";
  nav.style.position = "absolute";
  nav.style.top = "72px";
  nav.style.right = "4%";
  nav.style.background = "#fff";
  nav.style.padding = "20px";
  nav.style.borderRadius = "18px";
  nav.style.boxShadow = "0 10px 30px rgba(0,0,0,.1)";
});
